"use strict";\n\n// ===================== Mode multi-traducteurs (slug URL) =====================
function getTranslatorSlug() {
  try {
    const parts = (location.pathname || "/").split("/").filter(Boolean);
    if (!parts.length) return "";
    const slug = decodeURIComponent(parts[0]).trim();
    if (!slug || slug.toLowerCase() === "app") return "";
    return slug;
  } catch {
    return "";
  }
}

function getListUrlGeneric() {
  const slug = getTranslatorSlug();
  if (slug) return `/f95list_${slug}.json`;
  return `/f95list_ant28jsp.json`;
}






// ===== Boutons (pixel like andric31) =====
function setBtn(id, href){
  const el = document.getElementById(id);
  if(!el) return;
  if(href){
    el.href = href;
    el.style.display = "";
  }else{
    el.removeAttribute("href");
    el.style.display = "none";
  }
}

// ===== Actions (identique andric31) =====
function renderActionsIdenticalAndric31(game){
  const wrap = document.createElement("div");
  wrap.className = "actions";

  // Discord + F95
  const rowTop = document.createElement("div");
  rowTop.style.display = "flex";
  rowTop.style.gap = "8px";
  rowTop.style.flexWrap = "wrap";
  rowTop.appendChild(makeBtn(game.discordlink, "Discord", "💬"));
  rowTop.appendChild(makeBtn(game.url, "F95Zone", "🌐"));
  wrap.appendChild(rowTop);

  // Téléchargement
  const dl = (game.translation || game.mega || game.translationsExtra || "");
  wrap.appendChild(makeBtn(dl, "Télécharger la traduction (MEGA)", "📥"));

  // Archives (si champ)
  const arch = (game.translationsArchive || game.archive || game.archives || "");
  if(arch) wrap.appendChild(makeBtn(arch, "Archives", "🗂️"));

  return wrap;
}

const DEFAULT_URL = getListUrlGeneric();
// Base path de cette mini-app (pas de dossier /game)
const APP_PATH = `/${(getTranslatorSlug() || "ant28jsp")}/`;

// ====== Helpers URL / JSON ======

function getListUrl() {
  try {
    const p = new URLSearchParams(location.search);
    const src = (p.get("src") || "").trim();
    if (src) return src;
  } catch {}
  try {
    return (localStorage.getItem("f95listUrl") || "").trim() || DEFAULT_URL;
  } catch {
    return DEFAULT_URL;
  }
}

function getParamsFromUrl() {
  try {
    const p = new URLSearchParams(location.search);
    const id = (p.get("id") || "").trim();
    const uid = (p.get("uid") || "").trim();
    return { id: id || "", uid: uid || "" };
  } catch {
    return { id: "", uid: "" };
  }
}

function extractGames(raw) {
  if (Array.isArray(raw)) return raw;
  if (!raw || typeof raw !== "object") return [];
  const candidates = ["games", "list", "items", "data", "rows", "results"];
  for (const k of candidates) {
    if (Array.isArray(raw[k])) return raw[k];
  }
  for (const k of Object.keys(raw)) {
    if (Array.isArray(raw[k])) return raw[k];
  }
  return [];
}

// "25 décembre 2024" -> timestamp (ms)
function parseFrenchDateFR(s) {
  const str = String(s || "").trim().toLowerCase();
  if (!str) return 0;
  const months = {
    "janvier": 0,
    "février": 1,
    "fevrier": 1,
    "mars": 2,
    "avril": 3,
    "mai": 4,
    "juin": 5,
    "juillet": 6,
    "août": 7,
    "aout": 7,
    "septembre": 8,
    "octobre": 9,
    "novembre": 10,
    "décembre": 11,
    "decembre": 11,
  };
  const m = str.match(/(\d{1,2})\s+([a-zéûîôàèùç]+)\s+(\d{4})/i);
  if (!m) return 0;
  const day = parseInt(m[1], 10);
  const mon = months[m[2]];
  const year = parseInt(m[3], 10);
  if (!Number.isFinite(day) || !Number.isFinite(year) || mon === undefined) return 0;
  const d = new Date(year, mon, day, 12, 0, 0);
  return d.getTime();
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function setHtml(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html ?? "";
}

function show(id, cond) {
  const el = document.getElementById(id);
  if (el) el.style.display = cond ? "" : "none";
}

// =========================
// ✅ Routing (id central) + Collections + Séries
// =========================

function buildGameUrl(g) {
  const coll = (g.collection || "").toString().trim();
  const id = (g.id || "").toString().trim();
  const uid = (g.uid ?? "").toString().trim();

  if (coll) return `${APP_PATH}?id=${encodeURIComponent(coll)}&uid=${encodeURIComponent(uid)}`;
  if (id) return `${APP_PATH}?id=${encodeURIComponent(id)}`;
  return `${APP_PATH}?uid=${encodeURIComponent(uid)}`;
}

function getDisplayTitle(g) {
  // Règle: si c'est un enfant de collection (id vide + collection non vide),
  // on affiche UNIQUEMENT le titre du gameData (le title principal est celui de la collection).
  const id = (g?.id || "").toString().trim();
  const col = (g?.collection || "").toString().trim();
  if (!id && col) {
    return (g?.gameData?.title || "").toString().trim();
  }
  return (g?.cleanTitle || g?.title || "").toString().trim();
}

function getCollectionChildTitle(g) {
  // Strict: pas de fallback vers g.title (sinon doublons "Collection ...")
  return (g?.gameData?.title || "").toString().trim();
}

function getEntryRefs(g) {
  const refs = [];
  const id = (g?.id || "").toString().trim();
  if (id) refs.push(`id:${id}`);
  if (g?.uid !== undefined && g?.uid !== null) refs.push(`uid:${String(g.uid)}`);
  return refs;
}

function buildSeriesIndex(games) {
  const map = new Map(); // ref => [serieObj]
  for (const owner of games || []) {
    const s = owner?.serie;
    if (!s?.name || !Array.isArray(s.refs)) continue;

    const serieObj = {
      name: String(s.name),
      refs: s.refs.map((x) => String(x)),
      ownerUid: owner?.uid,
      ownerId: owner?.id || "",
    };

    // refs déclarées
    for (const ref of serieObj.refs) {
      if (!map.has(ref)) map.set(ref, []);
      map.get(ref).push(serieObj);
    }

    // rendre visible sur la page du owner (id central)
    for (const selfRef of getEntryRefs(owner)) {
      if (!map.has(selfRef)) map.set(selfRef, []);
      map.get(selfRef).push(serieObj);
    }
  }
  return map;
}

function getCurrentPageRefs({ kind, idParam, uidParam, entry }) {
  if (kind === "collectionChild") {
    return [`id:${String(idParam)}`, `uid:${String(uidParam)}`];
  }
  return getEntryRefs(entry);
}

function getSeriesForCurrentPage(pageRefs, seriesIndex) {
  const found = [];
  for (const r of pageRefs || []) {
    const arr = seriesIndex.get(r);
    if (arr) found.push(...arr);
  }
  const uniq = new Map();
  for (const s of found) {
    uniq.set(`${s.name}|${s.ownerUid}`, s);
  }
  return [...uniq.values()];
}

function resolveSerieRefsToEntries(serie, games) {
  const out = [];
  for (const ref of serie?.refs || []) {
    const [type, value] = String(ref).split(":");
    if (type === "id") {
      const g = (games || []).find((x) => String(x?.id) === String(value) && !x?.collection);
      if (g) out.push(g);
    } else if (type === "uid") {
      const g = (games || []).find((x) => String(x?.uid) === String(value));
      if (g) out.push(g);
    }
  }
  return out;
}

function resolveGamePage(params, games) {
  const id = (params?.id || "").toString().trim();
  const uid = (params?.uid || "").toString().trim();

  // 1) Sous-jeu de collection
  if (id && uid) {
    const child = (games || []).find(
      (g) => String(g?.uid) === String(uid) && String(g?.collection) === String(id)
    );
    if (!child) return { kind: "notfound" };

    const parent = (games || []).find((g) => String(g?.id) === String(id) && !g?.collection) || null;
    const siblings = (games || [])
      .filter((g) => String(g?.collection) === String(id))
      .sort((a, b) => Number(a?.uid) - Number(b?.uid));

    return { kind: "collectionChild", idParam: id, uidParam: uid, entry: child, parent, siblings };
  }

  // 2) id seul
  if (id) {
    const parentOrGame =
      (games || []).find((g) => String(g?.id) === String(id) && !g?.collection) || null;
    if (!parentOrGame) return { kind: "notfound" };

    const children = (games || [])
      .filter((g) => String(g?.collection) === String(id))
      .sort((a, b) => Number(a?.uid) - Number(b?.uid));

    if (children.length) return { kind: "collectionParent", idParam: id, entry: parentOrGame, children };
    return { kind: "normal", idParam: id, entry: parentOrGame };
  }

  // 3) uid seul
  if (uid) {
    const g = (games || []).find((x) => String(x?.uid) === String(uid)) || null;
    if (!g) return { kind: "notfound" };
    return { kind: "uidOnly", uidParam: uid, entry: g };
  }

  return { kind: "notfound" };
}

// ====== Related container: on va l'insérer après les tags OU après description (selon ton ordre)
// ✅ Ton ordre final: tags -> related -> description -> video -> boutons -> mega -> notes -> archive
function ensureRelatedContainer() {
  const anchor = document.getElementById("tags");
  if (!anchor) return null;

  let out = document.getElementById("relatedOut");
  if (!out) {
    out = document.createElement("div");
    out.id = "relatedOut";
    out.style.marginTop = "12px";
    out.style.display = "grid";
    out.style.gap = "10px";
    // insertion juste après tags (ordre demandé)
    anchor.parentNode.insertBefore(out, anchor.nextSibling);
  }
  return out;
}

function renderCollectionBlockForChild(parent) {
  const parentId = parent?.id ? String(parent.id) : "";
  const href = parentId ? `${APP_PATH}?id=${encodeURIComponent(parentId)}` : "";
  const label = parent ? (parent.cleanTitle || parent.title || parentId) : "Voir la collection";

  return `
    <div class="game-block collection-child-block">
      <h3>📦 Fait partie de la collection</h3>
      ${href ? `<a class="collection-parent-link" href="${href}">${escapeHtml(label)}</a>` : ``}
    </div>
  `;
}

function renderCollectionBlockForParent(parent, children) {
  if (!children || !children.length) return "";

  const items = children
    .map((g) => {
      const t = escapeHtml(getDisplayTitle(g, "collectionChild"));
      const href = `${APP_PATH}?id=${encodeURIComponent(parent.id)}&uid=${encodeURIComponent(g.uid)}`;
      return `<li><a href="${href}">${t}</a></li>`;
    })
    .join("");

  return `
    <div class="game-block collection-block">
      <h3>📦 Collection</h3>
      <ul class="collection-list">
        ${items}
      </ul>
    </div>
  `;
}

function renderSeriesBlocks(seriesList, games, currentCanonicalKey) {
  if (!Array.isArray(seriesList) || !seriesList.length) return "";

  return seriesList
    .map((serie) => {
      const items = resolveSerieRefsToEntries(serie, games);

      const li = items
        .map((g) => {
          const t = getCollectionChildTitle(g) || getDisplayTitle(g);
          const href = buildGameUrl(g);

          let key = "";
          const id = (g.id || "").toString().trim();
          const coll = (g.collection || "").toString().trim();
          if (coll) key = `c:${coll}|u:${g.uid}`;
          else if (id) key = `id:${id}`;
          else key = `uid:${g.uid}`;

          const isCurrent = key === currentCanonicalKey;

          return `<li style="margin:4px 0;">
            <a href="${href}" class="btn-link" style="${isCurrent ? "font-weight:700;text-decoration:underline;" : ""}">
              ${escapeHtml(t || "Sans titre")}
            </a>
          </li>`;
        })
        .join("");

      return `
        <div class="game-block serie-block">
          <h3>📚 Série : ${escapeHtml(serie.name)}</h3>
          <ul style="margin:0;padding-left:18px;">${li}</ul>
        </div>
      `;
    })
    .join("");
}

async function fetchJson(url) {
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status} sur ${url}`);
  return await r.json();
}

// ====== UI helpers ======

function $(id) {
  return document.getElementById(id);
}

function showError(msg) {
  const err = $("errBox");
  const card = $("card");
  const stats = $("statsOut");
  if (card) card.style.display = "none";
  if (stats) stats.style.display = "none";
  if (err) {
    err.style.display = "block";
    err.textContent = msg;
  }
}

function setText(id, text) {
  const el = $(id);
  if (el) el.textContent = text ?? "";
}

function setHref(id, href) {
  const el = $(id);
  if (!el) return;
  if (!href) {
    el.style.display = "none";
    el.removeAttribute("href");
  } else {
    el.style.display = "";
    el.href = href;
  }
}

/**
 * IMPORTANT:
 * - Si pas d'image => on laisse la cover en "placeholder" (PAS de favicon)
 * - Si image cassée => on repasse en placeholder (PAS de favicon)
 */
function setCover(url) {
  const img = $("cover");
  if (!img) return;

  const u = (url || "").trim();
  img.referrerPolicy = "no-referrer";

  if (!u) {
    img.removeAttribute("src");
    img.classList.add("is-placeholder");
    return;
  }

  img.classList.remove("is-placeholder");
  img.src = u;

  img.onerror = () => {
    img.onerror = null;
    img.removeAttribute("src");
    img.classList.add("is-placeholder");
  };
}

function renderTags(tags) {
  const box = $("tags");
  if (!box) return;
  box.innerHTML = "";
  (tags || []).forEach((t) => {
    if (!t) return;
    const s = document.createElement("span");
    s.className = "tagPill";
    s.textContent = String(t);
    box.appendChild(s);
  });
}

// ====== Badges ======

const CAT_ALLOWED = ["VN", "Collection"];
const ENGINE_ALLOWED = ["Ren'Py", "RPGM", "Unity", "Unreal Engine", "HTML", "Java", "Flash", "QSP", "WebGL", "RAGS", "Tads", "ADRIFT", "Others", "Wolf RPG"];
const STATUS_ALLOWED = ["Completed", "Abandoned", "Onhold"];

const ENGINE_RAW = {
  renpy: "Ren'Py",
  "ren'py": "Ren'Py",
  rpgm: "RPGM",
  rpgmaker: "RPGM",
  rpgmakermv: "RPGM",
  rpgmakermz: "RPGM",
  unity: "Unity",
  unreal: "Unreal Engine",
  "unrealengine": "Unreal Engine",
  "unreal engine": "Unreal Engine",
  ue4: "Unreal Engine",
  ue5: "Unreal Engine",
  html: "HTML",
  html5: "HTML",
  web: "HTML",
  java: "Java",
  flash: "Flash",
  qsp: "QSP",
  webgl: "WebGL",
  rags: "RAGS",
  tads: "Tads",
  adrift: "ADRIFT",
  others: "Others",
  other: "Others",
  wolf: "Wolf RPG",
  wolfrpg: "Wolf RPG",
};

function slug(s) {
  return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
}

const SEP_RE = /[\u2014\u2013\-:]/; // — – - :
const ucFirst = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

function cleanTitle(raw) {
  let t = String(raw || "").trim();
  let categories = [];
  let engines = [];
  let status = null;
  let othersExplicit = false;

  if (/^collection\b/i.test(t)) {
    categories.push("Collection");
    t = t.replace(/^collection[ :\-]*/i, "").trim();
  }

  const head = t.split(SEP_RE)[0];
  const tokens = head.split(/[\s/|,]+/).filter(Boolean);
  let cut = 0;

  for (let i = 0; i < tokens.length; i++) {
    const wRaw = tokens[i];
    const w = wRaw.toLowerCase();
    const norm = w.replace(/[^\w']/g, "");

    if (norm === "vn") {
      if (!categories.includes("VN")) categories.push("VN");
      cut = i + 1;
      continue;
    }

    if (
      norm === "wolf" &&
      tokens[i + 1] &&
      tokens[i + 1].toLowerCase().replace(/[^\w']/g, "") === "rpg"
    ) {
      if (!engines.includes("Wolf RPG")) engines.push("Wolf RPG");
      cut = i + 2;
      i++;
      continue;
    }

    if (norm === "wolf") break;

    if (norm === "flash") {
      if (!engines.includes("Flash")) engines.push("Flash");
      cut = i + 1;
      continue;
    }

    if (norm === "others" || norm === "other") {
      if (!engines.includes("Others")) engines.push("Others");
      othersExplicit = true;
      cut = i + 1;
      continue;
    }

    if (ENGINE_RAW[norm] !== undefined) {
      const eng = ENGINE_RAW[norm];
      if (eng && !engines.includes(eng)) engines.push(eng);
      cut = i + 1;
      continue;
    }

    const pretty = ucFirst(norm);
    if (STATUS_ALLOWED.includes(pretty)) {
      status = pretty;
      cut = i + 1;
      continue;
    }

    if (w === "&" || w === "and" || w === "/") {
      cut = i + 1;
      continue;
    }

    break;
  }

  if (cut > 0) {
    const headSlice = tokens.slice(0, cut).join(" ");
    t = t.slice(headSlice.length).trim();
    t = t.replace(/^[\u2014\u2013\-:|]+/, "").trim();
  }

  if (!status) status = "En cours";

  const allowedCat = new Set(CAT_ALLOWED);
  const allowedEng = new Set(ENGINE_ALLOWED);
  categories = categories.filter((c) => allowedCat.has(c));
  engines = engines.filter((e) => allowedEng.has(e));

  if (!othersExplicit && engines.includes("Others") && engines.some((e) => e !== "Others")) {
    engines = engines.filter((e) => e !== "Others");
  }

  return { title: t, categories, engines, status };
}

function makeBadge(type, value) {
  const b = document.createElement("span");
  b.className = `badge ${type}-${slug(value)}`;
  b.textContent = value;
  return b;
}

function renderBadgesFromGame(display, entry, isCollectionChild) {
  const wrap = $("badges");
  if (!wrap) return;
  wrap.innerHTML = "";

  const childTitle = String(display?.title || "");
  const parentTitle = String(entry?.title || "");

  // ✅ Enfant => badge Collection
  if (isCollectionChild) {
    wrap.appendChild(makeBadge("cat", "Collection"));
  }

  let c = cleanTitle(isCollectionChild ? childTitle : parentTitle);

  // Parent collection => badge Collection
  if (!isCollectionChild && c.categories.includes("Collection")) {
    wrap.appendChild(makeBadge("cat", "Collection"));
  }

  // VN seulement si pas enfant
  if (!isCollectionChild && c.categories.includes("VN")) {
    wrap.appendChild(makeBadge("cat", "VN"));
  }

  // Enfant => moteur/status priorité gameData
  if (isCollectionChild) {
    if (display?.engine) {
      const eng = ENGINE_RAW[slug(display.engine)] || display.engine;
      c.engines = [eng];
    } else if (!c.engines || c.engines.length === 0) {
      const cp = cleanTitle(parentTitle);
      c.engines = cp.engines || [];
    }

    if (display?.status) {
      c.status = display.status;
    } else if (!c.status) {
      const cp = cleanTitle(parentTitle);
      if (cp.status) c.status = cp.status;
    }
  }

  for (const eng of c.engines || []) {
    wrap.appendChild(makeBadge("eng", eng));
  }
  if (c.status) wrap.appendChild(makeBadge("status", c.status));
}

/**
 * ✅ Traduction status : badge uniquement (dans #badges)
 */
async function renderTranslationStatus(game) {
  if (!game?.url || !game?.title) return;

  try {
    const r = await fetch(
      `/api/f95status?url=${encodeURIComponent(game.url)}&storedTitle=${encodeURIComponent(game.title)}`,
      { cache: "no-store" }
    );
    if (!r.ok) return;

    const j = await r.json();
    if (!j?.ok || !j?.currentTitle) return;

    const badge = document.createElement("span");
    badge.classList.add("badge");

    const maj = document.getElementById("majState");
    if (maj) {
      maj.style.display = "";
      maj.classList.remove("maj-ok", "maj-ko");
    }

    if (j.isUpToDate) {
      badge.textContent = "✅ Traduction à jour";
      badge.classList.add("status-updated");
      if (maj) {
        maj.textContent = "✅ À jour";
        maj.classList.add("maj-ok");
      }
    } else {
      badge.textContent = "🔄 Traduction non à jour";
      badge.classList.add("status-outdated");
      if (maj) {
        maj.textContent = "🔄 Pas à jour";
        maj.classList.add("maj-ko");
      }
    }

    const wrap = $("badges");
    if (wrap) wrap.appendChild(badge);
  } catch {
    // Fallback local (si l'API n'est pas dispo) : compare "updatedAt" (F95) vs "updatedAtLocal" (ta date de traduction)
    try {
      const maj = document.getElementById("majState");
      const f95Ts = parseFrenchDateFR(game.updatedAt || "");
      const trdTs = Date.parse(game.updatedAtLocal || "");
      if (!maj) return;
      if (!f95Ts || !Number.isFinite(trdTs)) return;
      maj.style.display = "";
      maj.classList.remove("maj-ok", "maj-ko");
      if (trdTs >= f95Ts) {
        maj.textContent = "✅ À jour";
        maj.classList.add("maj-ok");
      } else {
        maj.textContent = "🔄 Pas à jour";
        maj.classList.add("maj-ko");
      }
    } catch {}
  }
}

// ============================================================================
// ✅ MENU ☰ (page game) — réutilise menu racine
// ============================================================================

function positionPopover(pop, anchorBtn) {
  const r = anchorBtn.getBoundingClientRect();
  const margin = 8;

  let left = Math.round(r.left);
  let top = Math.round(r.bottom + margin);

  const widthGuess = pop.getBoundingClientRect().width || 260;
  const maxLeft = window.innerWidth - widthGuess - 10;

  if (left > maxLeft) left = Math.max(10, maxLeft);
  if (left < 10) left = 10;

  pop.style.left = left + "px";
  pop.style.top = top + "px";
}

function initHamburgerMenu() {
  const btn = $("hamburgerBtn");
  if (!btn) return;

  try {
    window.ViewerMenu?.init?.();
  } catch {}

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();

    const pop = document.getElementById("topMenuPopover");
    if (!pop) return;

    const isOpen = !pop.classList.contains("hidden");
    if (isOpen) {
      try {
        window.ViewerMenu?.closeMenu?.();
      } catch {
        pop.classList.add("hidden");
      }
      btn.setAttribute("aria-expanded", "false");
      return;
    }

    pop.classList.remove("hidden");
    btn.setAttribute("aria-expanded", "true");
    positionPopover(pop, btn);
  });

  document.addEventListener("click", (e) => {
    const pop = document.getElementById("topMenuPopover");
    if (!pop) return;

    const target = e.target;
    if (!pop.contains(target) && !btn.contains(target)) {
      try {
        window.ViewerMenu?.closeMenu?.();
      } catch {
        pop.classList.add("hidden");
      }
      btn.setAttribute("aria-expanded", "false");
    }
  });

  window.addEventListener("resize", () => {
    const pop = document.getElementById("topMenuPopover");
    if (pop && !pop.classList.contains("hidden")) positionPopover(pop, btn);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    try {
      window.ViewerMenu?.closeMenu?.();
    } catch {}
    try {
      window.ViewerMenu?.closeAbout?.();
    } catch {}
    try {
      window.ViewerMenu?.closeExtension?.();
    } catch {}
    try {
      window.ViewerMenuExtension?.close?.();
    } catch {}
  });
}

// ====== Counters ======

function formatInt(n) {
  const x = Number(n);
  if (!Number.isFinite(x)) return "0";
  try {
    return x.toLocaleString("fr-FR");
  } catch {
    return String(Math.floor(x));
  }
}

function showStatsBox() {
  const stats = $("statsOut");
  if (stats) stats.style.display = "";
}

async function counterGet(id) {
  const r = await fetch(`/api/counter?op=get&id=${encodeURIComponent(id)}`, { cache: "no-store" });
  if (!r.ok) throw new Error("counter get HTTP " + r.status);
  return await r.json();
}

async function counterHit(id, kind) {
  const r = await fetch(
    `/api/counter?op=hit&kind=${encodeURIComponent(kind)}&id=${encodeURIComponent(id)}`,
    { cache: "no-store" }
  );
  if (!r.ok) throw new Error("counter hit HTTP " + r.status);
  return await r.json();
}

async function counterUnhit(id, kind) {
  const r = await fetch(
    `/api/counter?op=unhit&kind=${encodeURIComponent(kind)}&id=${encodeURIComponent(id)}`,
    { cache: "no-store" }
  );
  if (!r.ok) throw new Error("counter unhit HTTP " + r.status);
  return await r.json();
}

function getMyLike(gameId) {
  try {
    return localStorage.getItem(`like_${gameId}`) === "1";
  } catch {
    return false;
  }
}
function setMyLike(gameId, v) {
  try {
    localStorage.setItem(`like_${gameId}`, v ? "1" : "0");
  } catch {}
}
function updateLikeBtn(gameId) {
  const b = $("btnLike");
  if (!b) return;

  const liked = getMyLike(gameId);
  b.textContent = liked ? "❤️" : "🤍";
  b.setAttribute("aria-label", liked ? "Je n’aime plus" : "J’aime");
}

function setLikesFromJson(j) {
  if (!$("statLikes")) return;
  const val = Number(j?.likes);
  setText("statLikes", Number.isFinite(val) ? formatInt(val) : "0");
}

function cooldownKey(kind, gameId) {
  return `cooldown_${kind}_${gameId}`;
}

function inCooldown(kind, gameId, ms) {
  try {
    const k = cooldownKey(kind, gameId);
    const last = Number(localStorage.getItem(k) || "0");
    const now = Date.now();
    if (now - last < ms) return true;
    localStorage.setItem(k, String(now));
    return false;
  } catch {
    // si localStorage bloqué, on ne bloque pas
    return false;
  }
}

async function initCounters(gameId, megaHref, archiveHref) {
  const VIEW_COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes
  const MEGA_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutes

  // 1) Vue (anti-refresh abusif)
  const skipViewHit = inCooldown("view", gameId, VIEW_COOLDOWN_MS);

  try {
    const j = skipViewHit ? await counterGet(gameId) : await counterHit(gameId, "view");
    if (j?.ok) {
      setText("statViews", formatInt(j.views));
      setText("statMegaClicks", formatInt(j.mega));
      setLikesFromJson(j);
      showStatsBox();
    }
  } catch {
    // fallback basique
    try {
      const j = await counterGet(gameId);
      if (j?.ok) {
        setText("statViews", formatInt(j.views));
        setText("statMegaClicks", formatInt(j.mega));
        setLikesFromJson(j);
        showStatsBox();
      }
    } catch {
      setText("statViews", "—");
      setText("statMegaClicks", "—");
      if ($("statLikes")) setText("statLikes", "—");
      showStatsBox();
    }
  }

  // 2) 📥 Téléchargements (MEGA + Archives → même compteur)
  const bindDownload = (btnId, href) => {
    if (!href) return;
    const btn = $(btnId);
    if (!btn) return;

    if (btn.dataset.boundMega === "1") return; // ✅ anti-double bind
    btn.dataset.boundMega = "1";

    btn.addEventListener(
      "click",
      async () => {
        // ✅ anti spam clic (local)
        if (inCooldown("megaClick", gameId, MEGA_COOLDOWN_MS)) return;

        try {
          const j = await counterHit(gameId, "mega");
          if (j?.ok) {
            setText("statMegaClicks", formatInt(j.mega));
            showStatsBox();
          }
        } catch {}
      },
      { passive: true }
    );
  };

  bindDownload("btnMega", megaHref);
  bindDownload("archiveLink", archiveHref);

  // 3) ❤️ Like toggle
  const btnLike = $("btnLike");
  if (btnLike && $("statLikes")) {
    updateLikeBtn(gameId);

    // ✅ anti double bind (si initCounters est rappelée)
    if (btnLike.dataset.boundLike === "1") return;
    btnLike.dataset.boundLike = "1";

    btnLike.addEventListener("click", async () => {
      // ✅ anti spam like (local)
      if (inCooldown("likeClick", gameId, 1500)) return;

      const liked = getMyLike(gameId);

      try {
        let j;
        if (!liked) {
          j = await counterHit(gameId, "like");
          if (j?.ok) {
            setMyLike(gameId, true);
            setLikesFromJson(j);
            updateLikeBtn(gameId);
            showStatsBox();
          }
          return;
        }

        j = await counterUnhit(gameId, "like");
        if (j?.ok) {
          setMyLike(gameId, false);
          setLikesFromJson(j);
          updateLikeBtn(gameId);
          showStatsBox();
        }
      } catch {
        // silencieux (unhit pas supporté)
      }
    });
  }
}

// ============================================================================
// ✅ COMPTEUR UID ONLY (OPTION A)
// - id est ignoré pour les stats
// - uid est TOUJOURS présent dans ta base
// - garantit un compteur unique quel que soit l’URL
// ============================================================================
function buildCounterKeyFromEntry(entry) {
  const uid = String(entry?.uid ?? "").trim();
  return uid ? `uid:${uid}` : "";
}

// ====== Rating 4 ======

const RATING4_LABELS = {
  1: "Traduction à refaire",
  2: "Traduction avec des défauts",
  3: "Traduction correcte",
  4: "Bonne traduction",
};

async function rating4Get(id) {
  const r = await fetch(`/api/rating4?op=get&id=${encodeURIComponent(id)}`, { cache: "no-store" });
  if (!r.ok) throw new Error("rating4 get HTTP " + r.status);
  return await r.json();
}

async function rating4Vote(id, v, prev) {
  const qs = new URLSearchParams({
    op: "vote",
    id: String(id),
    v: String(v),
    prev: String(prev || 0),
  });
  const r = await fetch(`/api/rating4?${qs.toString()}`, { cache: "no-store" });
  if (!r.ok) throw new Error("rating4 vote HTTP " + r.status);
  return await r.json();
}

function getMyVote4(gameId) {
  try {
    const v = Number(localStorage.getItem(`rating4_${gameId}`) || "0");
    return Number.isFinite(v) ? v : 0;
  } catch {
    return 0;
  }
}

function setMyVote4(gameId, v) {
  try {
    localStorage.setItem(`rating4_${gameId}`, String(v));
  } catch {}
}

function renderRating4UI(gameId, data, enabled = true) {
  const choices = $("ratingChoices");
  const avgEl = $("ratingAvg");
  const countEl = $("ratingCount");
  const msgEl = $("ratingMsg");
  if (!choices || !avgEl || !countEl) return;

  const avg = Number(data?.avg) || 0;
  const count = Number(data?.count) || 0;
  const myVote = getMyVote4(gameId);

  enabled = !!enabled && !!data?.ok;

  avgEl.textContent = avg > 0 ? avg.toFixed(1) + "/4" : "—";
  countEl.textContent = String(count);

  choices.innerHTML = "";

  if (!enabled) {
    // ⭐ Affiche les étoiles même si l'API n'est pas disponible (mode désactivé)
    for (let i = 1; i <= 4; i++) {
      const star = document.createElement("button");
      star.type = "button";
      star.className = "ratingStar";
      star.textContent = "☆";
      star.disabled = true;
      star.setAttribute("aria-label", `${i}/4`);
      choices.appendChild(star);
    }
    if (msgEl) msgEl.textContent = "Notation désactivée.";
    return;
  }


  const setVisual = (hoverValue) => {
    const v =
      hoverValue === 0 || typeof hoverValue === "number" ? hoverValue : getMyVote4(gameId) || 0;

    [...choices.querySelectorAll(".ratingStar")].forEach((btn, idx) => {
      btn.textContent = idx + 1 <= v ? "★" : "☆";
    });
  };

  const restoreMsg = () => {
    const v = getMyVote4(gameId);
    if (!msgEl) return;
    msgEl.textContent = v
      ? `Ta note : ${v}/4 — ${RATING4_LABELS[v]} (tu peux changer ta note)`
      : "Clique sur les étoiles pour noter la traduction.";
  };

  if (myVote) {
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "ratingCancel";
    cancel.textContent = "🗑️";
    cancel.setAttribute("aria-label", "Annuler ma note");

    cancel.addEventListener("mouseenter", () => {
      setVisual(0);
      if (msgEl) msgEl.textContent = "Annuler ma note";
    });
    cancel.addEventListener("mouseleave", () => {
      setVisual(null);
      restoreMsg();
    });

    cancel.addEventListener("click", async () => {
      const prev = getMyVote4(gameId);
      if (!prev) return;
      try {
        const res = await rating4Vote(gameId, 0, prev);
        if (res?.ok) {
          try {
            localStorage.removeItem(`rating4_${gameId}`);
          } catch {}
          renderRating4UI(gameId, res);
          if (msgEl) msgEl.textContent = "Note supprimée ✅";
        }
      } catch {
        if (msgEl) msgEl.textContent = "Erreur lors de l’annulation.";
      }
    });

    choices.appendChild(cancel);
  }

  for (let i = 1; i <= 4; i++) {
    const star = document.createElement("button");
    star.type = "button";
    star.className = "ratingStar";
    star.textContent = "☆";
    star.setAttribute("aria-label", `${i}/4 — ${RATING4_LABELS[i]}`);

    star.addEventListener("mouseenter", () => {
      setVisual(i);
      if (msgEl) msgEl.textContent = `${i}/4 — ${RATING4_LABELS[i]}`;
    });
    star.addEventListener("mouseleave", () => {
      setVisual(null);
      restoreMsg();
    });

    star.addEventListener("click", async () => {
      const prev = getMyVote4(gameId);
      if (prev === i) {
        if (msgEl) msgEl.textContent = "C’est déjà ta note actuelle ✅";
        return;
      }
      try {
        const res = await rating4Vote(gameId, i, prev);
        if (res?.ok) {
          setMyVote4(gameId, i);
          renderRating4UI(gameId, res);
          if (msgEl) msgEl.textContent = prev ? "Note modifiée ✅" : "Merci pour ton vote ⭐";
        }
      } catch {
        if (msgEl) msgEl.textContent = "Erreur lors du vote.";
      }
    });

    choices.appendChild(star);
  }

  setVisual(null);
  restoreMsg();
}

// =========================
// ✅ Blocs "nouveaux champs" (ordre demandé)
// Chaque champ = son encadré (game-block)
// =========================

function ensureBlockAfter(anchorEl, id) {
  if (!anchorEl || !anchorEl.parentNode) return null;

  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement("div");
    el.id = id;
    anchorEl.parentNode.insertBefore(el, anchorEl.nextSibling);
  }
  return el;
}

function ensureBlockBefore(anchorEl, id) {
  if (!anchorEl || !anchorEl.parentNode) return null;

  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement("div");
    el.id = id;
    anchorEl.parentNode.insertBefore(el, anchorEl);
  }
  return el;
}

function renderTextBlock({ id, title, text, muted }) {
  const t = (text || "").trim();
  if (!t) {
    show(id, false);
    return;
  }
  const htmlText = escapeHtml(t).replace(/\n/g, "<br>");
  setHtml(
    id,
    `
    <div class="game-block">
      <h3>${escapeHtml(title)}</h3>
      <div style="color:${muted ? "var(--muted)" : "var(--fg)"}; font-size:${muted ? "13px" : "14px"}; line-height:1.45;">
        ${htmlText}
      </div>
    </div>
  `
  );
  show(id, true);
}

function renderLinkBlock({ id, title, href, label }) {
  const u = (href || "").trim();
  if (!u) {
    show(id, false);
    return;
  }

  const linkId = `btn_${id}`; // ex: btn_archiveHost

  setHtml(
    id,
    `
    <div class="game-block">
      <h3>${escapeHtml(title)}</h3>
      <a id="${linkId}" class="btnLike" target="_blank" rel="noopener"
         href="${escapeHtml(u)}" style="display:inline-flex;">
        ${escapeHtml(label)}
      </a>
    </div>
  `
  );
  show(id, true);
}

function renderVideoBlock({ id, videoUrl }) {
  const u = (videoUrl || "").trim();
  if (!u) {
    show(id, false);
    return;
  }
  setHtml(
    id,
    `
    <div class="game-block">
      <iframe
        src="${escapeHtml(u)}"
        referrerpolicy="strict-origin-when-cross-origin"
        style="width:100%; aspect-ratio:16/9; border-radius:12px; border:1px solid var(--border);"
        loading="lazy"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen>
      </iframe>
    </div>
  `
  );
  show(id, true);
}

// ====== Main ======

(async function main() {
  try {
    initHamburgerMenu();

    const { id: idParam, uid: uidParam } = getParamsFromUrl();

    if (!idParam && !uidParam) {
      showError(
        `Aucun paramètre dans l’URL. Exemples : ${APP_PATH}?id=215277  ou  ${APP_PATH}?id=17373&uid=898  ou  ${APP_PATH}?uid=898`
      );
      return;
    }

    const listUrl = getListUrl();
    const raw = await fetchJson(listUrl);
    const list = extractGames(raw);

    const page = resolveGamePage({ id: idParam, uid: uidParam }, list);

    if (page.kind === "notfound") {
      showError(`Jeu introuvable (id=${idParam || "-"} uid=${uidParam || "-"}) dans f95list.json`);
      return;
    }

    // entry = objet principal (discord/mega/notes/description)
    const entry = page.entry;

    // display = données "jeu" (gameData si présent)
    const display = entry?.gameData ? entry.gameData : entry;

    const counterKey = buildCounterKeyFromEntry(entry);

    const isCollectionChild = page.kind === "collectionChild" && entry && entry.gameData;

    const title = (getDisplayTitle(entry) || getDisplayTitle(display) || `Jeu ${idParam || uidParam}`).trim();
    document.title = title;

    // 1) Titre + cover + tags
    setText("title", title);
    setCover(display.imageUrl || entry.imageUrl || "");
    renderTags(display.tags || entry.tags || []);

    // badges
    renderBadgesFromGame(display, entry, isCollectionChild);
    renderTranslationStatus(entry);

    // ✅ ANCRAGES HTML existants
    const tagsEl = document.getElementById("tags");
    const btnRow = document.querySelector(".btnRow");
    const btnMainRow = document.querySelector(".btnMainRow");
    const ratingBox = document.getElementById("ratingBox");

    // =========================
    // 2) Related (après tags)
    // =========================
    const relatedOut = ensureRelatedContainer();
    if (relatedOut) {
      const parts = [];

      if (page.kind === "collectionParent") {
        parts.push(renderCollectionBlockForParent(entry, page.children));
      } else if (page.kind === "collectionChild") {
        parts.push(renderCollectionBlockForChild(page.parent));
      }

      const seriesIndex = buildSeriesIndex(list);
      const pageRefs = getCurrentPageRefs({ kind: page.kind, idParam: idParam, uidParam: uidParam, entry });
      const seriesList = getSeriesForCurrentPage(pageRefs, seriesIndex);

      let canonicalKey = "";
      if (page.kind === "collectionChild") canonicalKey = `c:${page.idParam}|u:${page.uidParam}`;
      else if (entry?.id) canonicalKey = `id:${String(entry.id).trim()}`;
      else canonicalKey = `uid:${String(entry.uid).trim()}`;

      parts.push(renderSeriesBlocks(seriesList, list, canonicalKey));

      relatedOut.innerHTML = parts.filter(Boolean).join("");
    }

    // =========================
    // 3) Description (juste après related, avant vidéo)
    // =========================
    const descAnchor = relatedOut || tagsEl;
    const descBox = document.getElementById("descriptionBox");
    const descTextEl = document.getElementById("descriptionText");
    
    if (descBox && descAnchor && descAnchor.parentNode) {
      // ✅ force la position: juste après related/tags (donc AVANT les liens)
      descAnchor.parentNode.insertBefore(descBox, descAnchor.nextSibling);
    }
    
    const description = (entry.description || "").trim();
    if (description && descBox && descTextEl) {
      descTextEl.innerHTML = escapeHtml(description).replace(/\n/g, "<br>");
      descBox.style.display = "";
    } else if (descBox) {
      descBox.style.display = "none";
    }

    // =========================
    // 4) Vidéo (si présent) sous description
    // =========================
    const videoAnchor = (descBox && descBox.style.display !== "none") ? descBox : (relatedOut || tagsEl);
    
    const videoHost = ensureBlockAfter(videoAnchor, "videoHost");
    renderVideoBlock({
      id: "videoHost",
      videoUrl: (entry.videoUrl || "").trim(),
    });

    // =========================
    // 5) Boutons Discord + F95 (inchangés)
    // =========================
    setHref("btnDiscord", (entry.discordlink || "").trim());
    if ($("btnDiscord")) {
      $("btnDiscord").textContent = "💬 Discord";
      $("btnDiscord").classList.add("btn-discord");
    }
    
    setHref("btnF95", (entry.url || "").trim());
    if ($("btnF95")) {
      $("btnF95").innerHTML = '<span class="f95-white"> F95</span><span class="f95-red">Zone</span>';
      $("btnF95").classList.add("btn-f95");
    }

    // =========================
    // 6) MEGA (bouton existant)
    // =========================
    const megaHref = (entry.translation || "").trim();
    const archiveHref = (entry.translationsArchive || "").trim();
    setHref("btnMega", megaHref);
    if ($("btnMega")) $("btnMega").textContent = "📥 Télécharger la traduction (MEGA)";

    // =========================
    // 7) Informations (encadré sous la notation)
    // =========================
    const notes = (entry.notes || "").trim();
    if (notes) {
      setHtml("notesText", escapeHtml(notes).replace(/\n/g, "<br>"));
      show("notesBox", true);
    } else {
      show("notesBox", false);
    }
    
    // =========================
    // 8) Archives (bouton HTML existant sous Notes) — SANS encadré
    // =========================
    setHref("archiveLink", archiveHref);
    if ($("archiveLink")) $("archiveLink").textContent = "📦 Archives de la traduction";
    
    const ab = $("archiveBox");
    if (ab) ab.style.display = archiveHref ? "flex" : "none";

    // ⛔ Bloquer clic droit sur ARCHIVES
    const archiveLink = document.getElementById("archiveLink");
    if (archiveLink) {
      archiveLink.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        return false;
      });
    }

    // =========================
    // ✅ Analytics key (unique)
    // =========================
    const analyticsKey = counterKey;
    
    await initCounters(counterKey, megaHref, archiveHref);

    // ⛔ Bloquer clic droit sur MEGA
    const btnMega = document.getElementById("btnMega");
    if (btnMega) {
      btnMega.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        return false;
      });
    }

    // Rating
    try {
      const j = await rating4Get(analyticsKey);
      if (j?.ok) renderRating4UI(analyticsKey, j, true);
    } catch {
      // API non dispo → on affiche quand même les étoiles (désactivées)
      renderRating4UI(analyticsKey, { ok: false, avg: 0, count: 0 }, false);
    }

    // =========================
    // ⭐ Déplacer la notation en bas de l'encadré principal
    // =========================
    const cardInner = document.querySelector(".cardInner");
    const ratingBoxEl = document.getElementById("ratingBox");
    if (cardInner && ratingBoxEl) {
      cardInner.appendChild(ratingBoxEl);
    }

  } catch (e) {
    showError(`Erreur: ${e?.message || e}`);
  }
})();


// ===== Buttons helpers (forced styling) =====
function makeBtn(href, label, emoji){
  const a = document.createElement("a");
  a.className = "btn";
  a.target = "_blank";
  a.rel = "noopener noreferrer";
  a.href = href || "#";
  if(!href) a.classList.add("disabled");
  a.textContent = (emoji ? (emoji + " ") : "") + label;
  return a;
}


  try{
    setBtn("btnDiscord", game.discordlink || "");
    setBtn("btnF95", game.url || "");
    // MEGA / translation
    const dl = (game.translation || game.mega || "");
    setBtn("btnMega", dl);
    // Archives
    const arch = (game.translationsArchive || "");
    const box = document.getElementById("archiveBox");
    const link = document.getElementById("archiveLink");
    if(box && link){
      if(arch){
        link.href = arch;
        box.style.display = "flex";
      }else{
        box.style.display = "none";
      }
    }
  }catch(e){}
